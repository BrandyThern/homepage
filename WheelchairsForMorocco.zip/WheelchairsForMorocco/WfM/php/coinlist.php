<!DOCTYPE HTML>
<html>
<head>
<title></title>
<meta name="author" content="Brandy">
<meta name="editor" content="html-editor phase 5">
</head>
<body text="#000000" bgcolor="#EBEBFF" link="#000000" alink="#000000" vlink="#000000">
 <style type="text/css">
          a:link { text-decoration:none;  }
          a:visited { text-decoration:none;  }
          a:hover { text-decoration:underline ;  }
          a:active { text-decoration:underline ;}
          a:focus { text-decoration:underline ;  }

 </style>

<?php
// Verbindung zur Datenbank aufbauen.
# index.php (in document root (D:/xampp/htdocs/css-garten/css-garten/php))
include __DIR__ . '/connect.php';

$select = $db->query("SELECT `Name` , `ID`
                      FROM `currencies`");
$names = $select->fetchAll(PDO::FETCH_OBJ);
foreach($names as $Galama){
print ("<a href=\"http://localhost/css-garten/css-garten/php/selectedcoin.php?id=$Galama->ID\"  target=\"main2\" >");
print $Galama->Name ;
print ("</a>");
print("<br>\n");
}
?>
</body>
</html>