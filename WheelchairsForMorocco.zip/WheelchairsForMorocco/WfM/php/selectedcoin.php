<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title></title>
<meta name="author" content="Brandy">
<meta name="editor" content="html-editor phase 5">
<meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="./css/elegant.css" id="stylesheet">
</head>
<body text="#000000" bgcolor="#EBEBFF" style="font-size:16px">
 <style type="text/css">
          a:link { text-decoration:none;  }
          a:visited { text-decoration:none;  }
          a:hover { text-decoration:underline ;  }
          a:active { text-decoration:underline ;}
          a:focus { text-decoration:underline ;  }
          a:link {color: darkblue;}
 </style>
 <style>

          background: lightblue;
  </style>
<?php
# index.php (in document root (http://localhost/css-garten/css-garten/php))
include __DIR__ . '/connect.php';
$id = $_GET['id'];
$sql = "SELECT * FROM currencies";
$select = $db->query($sql);
$names = $select->fetchAll(PDO::FETCH_OBJ);
foreach($names as $galama){
  if($galama->ID == $id){

    print($galama->Name) ;
    print("  ");
    print($galama->Shortcut) ;
    print("<br>\n");
    print("Algorithmus: ");
    print($galama->Algo) ;
    print("<br>\n");
    if($galama->offline == ""){
         print ("<a href=\"$galama->URL\" target=\"_blank\">$galama->URL</a>");
    }else{
         print("Website is offline.");
    }
    print("<br>\n");
    if($galama->Comment != ""){
         print("Kommentar: ");
         print($galama->Comment) ;
         print("<br>\n");
    }
    if($galama->not_listed != ""){
         print("noch nicht/nicht mehr gelistet");
         print("<br>\n");
    }else{
         print("Gelistet auf: ");
         print("<br>\n");
         if($galama->Crex24 != ""){
                 print("<a href=\"https://crex24.com/de/\" target=\"_blank\">Crex24</a>");
                 print("<br>\n");
         }
         if($galama->Btc_alpha != ""){
                 print("<a href=\"https://btc-alpha.com/exchange/\" target=\"_blank\">Btc-alpha</a>");
                 print("<br>\n");
         }
         if($galama->stocks_exchange != ""){
                 print("<a href=\"https://stocks.exchange/trade\" target=\"_blank\">Stocks.Exchange</a>");
                 print("<br>\n");
         }
         if($galama->tradeogre != ""){
                 print("<a href=\"https://tradeogre.com/markets\" target=\"_blank\">tradeogre</a>");
                 print("<br>\n");
         }
         if($galama->Hitbtc != ""){
                 print("<a href=\"https://hitbtc.com/\" target=\"_blank\">Hitbtc</a>");
                 print("<br>\n");
         }
         if($galama->Bittrex != ""){
                 print("<a href=\"https://bittrex.com/\" target=\"_blank\">Bittrex</a>");
                 print("<br>\n");
         }
         if($galama->altex_exchange != ""){
                 print("<a href=\"https://altex.exchange/\" target=\"_blank\">altex.exchange</a>");
                 print("<br>\n");
         }
         if($galama->Cryptopia != ""){
                 print("<a href=\"https://www.cryptopia.co.nz/\" target=\"_blank\">Cryptopia</a>");
                 print("<br>\n");
         }
         if($galama->Poloniex != ""){
                 print("<a href=\"https://poloniex.com/\" target=\"_blank\">Poloniex</a>");
                 print("<br>\n");
         }
         if($galama->graviex_net != ""){
                 print("<a href=\"https://graviex.net/\" target=\"_blank\">graviex.net</a>");
                 print("<br>\n");
         }
         if($galama->livecoin_net != ""){
                 print("<a href=\"https://www.livecoin.net/\" target=\"_blank\">livecoin.net</a>");
                 print("<br>\n");
         }
         if($galama->southXchange != ""){
                 print("<a href=\"https://www.southxchange.com/\" target=\"_blank\">southXchange</a>");
                 print("<br>\n");
         }
         if($galama->tradesatoshi != ""){
                 print("<a href=\"https://tradesatoshi.com/Exchange\" target=\"_blank\">tradesatoshi</a>");
                 print("<br>\n");
         }
         if($galama->Binance != ""){
                 print("<a href=\"https://www.binance.com/\" target=\"_blank\">Binance</a>");
                 print("<br>\n");
         }
         if($galama->Bitbns != ""){
                 print("<a href=\"https://bitbns.com/\" target=\"_blank\">Bitbns</a>");
                 print("<br>\n");
         }
         if($galama->Kucoin != ""){
                 print("<a href=\"https://www.kucoin.com/#/\" target=\"_blank\">Kucoin</a>");
                 print("<br>\n");
         }
         if($galama->CoinSpot != ""){
                 print("<a href=\"https://www.coinspot.com.au/\" target=\"_blank\">CoinSpot</a>");
                 print("<br>\n");
         }
         if($galama->Qryptos != ""){
                 print("<a href=\"https://www.qryptos.com/\" target=\"_blank\">Qryptos</a>");
                 print("<br>\n");
         }
         if($galama->Cryptohub != ""){
                 print("<a href=\"https://cryptohub.online/\" target=\"_blank\">Cryptohub</a>");
                 print("<br>\n");
         }
         if($galama->Vebitcoin != ""){
                 print("<a href=\"https://www.vebitcoin.com/\" target=\"_blank\">Vebitcoin</a>");
                 print("<br>\n");
         }
         if($galama->vicex_io != ""){
                 print("<a href=\"https://vicex.io/\" target=\"_blank\">vicex.io</a>");
                 print("<br>\n");
         }
         if($galama->next_exchange != ""){
                 print("<a href=\"https://next.exchange/\" target=\"_blank\">next.exchange</a>");
                 print("<br>\n");
         }
         if($galama->Octaex != ""){
                 print("<a href=\"https://octaex.com/\" target=\"_blank\">Octaex</a>");
                 print("<br>\n");
         }
    }



  }
}


?>

</body>
</html>