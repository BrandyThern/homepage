<!DOCTYPE HTML>
<html>
<head>
<title></title>
<meta name="author" content="Brandy">
<meta name="editor" content="html-editor phase 5">
</head>
<body text="#000000" bgcolor="#EBEBFF" link="#000000" alink="#000000" vlink="#000000" style="font-size: 12px">
 <style type="text/css">
          a:link { text-decoration:none;  }
          a:visited { text-decoration:none;  }
          a:hover { text-decoration:underline ;  }
          a:active { text-decoration:underline ;}
          a:focus { text-decoration:underline ;  }

 </style>
<?php

# index.php (in document root (http://localhost/css-garten/css-garten/php))
include __DIR__ . '/connect.php';
$select = $db->query("SELECT `Currency` , `Address`
                      FROM `donationwallets`");
$names = $select->fetchAll(PDO::FETCH_OBJ);
foreach($names as $Galama){
print("<h2>");
print $Galama->Currency ;
print("</h2>\n");
print $Galama->Address;
print("<br>\n");
}

?>
</body>
</html>